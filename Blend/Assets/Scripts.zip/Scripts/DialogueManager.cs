﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class DialogueManager : MonoBehaviour {

    public Queue<string> sentances;
    public Text nameText;
    public Text dialogueText;
    public Animator animator;
    PlayerControls playerManager;



	// Use this for initialization
	void Start () {
        sentances = new Queue<string>();
        Animator animatorComp = GetComponent<Animator>();

		
	}

    public void Update()
    {
        
        if (animator.GetBool("isOpen"))
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                DisplayNextSentance();
            }

           

            
        }

    }

    public void StartDialogue(Dialogue dialogue)
    {
        animator.SetBool("isOpen", true);
        playerManager.speed = 0;

        nameText.text = dialogue.name;
        

        sentances.Clear();

        foreach(string sentance in dialogue.sentances)
        {
            sentances.Enqueue(sentance);
        }

        DisplayNextSentance();
    }

    public void DisplayNextSentance()
    {
        if(sentances.Count == 0)
        {
            EndDialogue();
            return;
        }

        string sentance = sentances.Dequeue();
        dialogueText.text = sentance;


    }

    public void EndDialogue()
    {
        animator.SetBool("isOpen", false);
    }
	
}
